// app/api/webhooks/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { mutation } from '../../../convex/_generated/server';

export const updateUserProStatus = mutation(async ({ db }, userId: string) => {
  const user = await db.query('users').withIndex('by_user_id', (q) => q.eq('userId', userId)).first();
  if (user) {
    await db.patch(user._id, {
      isPro: true,
      proSince: Date.now(),
    });
  }
});

export async function POST(req: NextRequest) {
  const { event, data } = await req.json();

  if (event === 'payment.success') {
    const userId = data.request_id; // Extracted from the request_id set during checkout session creation
    try {
      await updateUserProStatus({ db }, userId);
      return NextResponse.json({ message: 'User status updated successfully' }, { status: 200 });
    } catch (error) {
      console.error('Error updating user status:', error);
      return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
  } else {
    return NextResponse.json({ error: 'Unhandled event type' }, { status: 400 });
  }
}